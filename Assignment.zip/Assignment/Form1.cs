﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cmbstatus.SelectedIndex = 0;
            txttotalbill.Text = "0";
            cmbProduct.SelectedIndex = 0;
        }

        private void cmbstatus_SelectedIndexChanged(object sender, EventArgs e)
        {
          
                CheckBoxstatus();
                CalculateBill();
        }
        private void CheckBoxstatus()
        {
            long i=0;
            if (cmbstatus.SelectedIndex == 0)
            {
                i = 0;
                txtdiscount.Text =   i.ToString();
              
            }
            if (cmbstatus.SelectedIndex == 1)
            {
                i = 30;
                txtdiscount.Text =   i.ToString();
               
            }

            if (cmbstatus.SelectedIndex == 2)
            {
                i = 10;
                txtdiscount.Text = i.ToString();
              
            }
            if (cmbstatus.SelectedIndex == 3)
            {
                i = 5;
                txtdiscount.Text = i.ToString();
              
            }
            if (cmbstatus.SelectedIndex == 4)
            {
                i = 0;

                // Code for calculating discount amount 

                long totalbill = long.Parse(txttotalbill.Text.Trim());

                if (totalbill >= 100)
                {
                    long dis = totalbill / 100;
                    i = dis * 5;
                }
                txtdiscount.Text = i.ToString();
              
                CalculateBill();
            }
        }

        private void txttotalbill_TextChanged(object sender, EventArgs e)
        {

            CheckBill();
            CheckBoxstatus();
            CalculateBill();

        }
        private void CheckBill()
        {
            try
            {
                 
                                  
                long bill = long.Parse(txttotalbill.Text.Trim());
                CalculateBill();

            }
            catch (Exception er)
            {
            }
        }

        private void CalculateBill()
        {
            try
            {
                long totalbill = long.Parse(txttotalbill.Text.Trim());
                long discount = long.Parse(txtdiscount.Text.Trim());
                long actualbill = totalbill - (totalbill * discount/100);
                txtDiscountBill.Text = "$" + actualbill.ToString();
            }
            catch (Exception er)
            {
            }
        }

       
        private void cmbProduct_SelectedIndexChanged(object sender, EventArgs e)
        {
            CheckProductType();
        }
        private void CheckProductType()
        {
            try
            {

                if (cmbProduct.SelectedIndex == 6)
                {
                    cmbstatus.SelectedIndex = 0;
                    cmbstatus.Enabled = false;
                    txtdiscount.Text = "0";
                }
                else
                {
                    cmbstatus.Enabled = true;
                }
               
            }
            catch (Exception er)
            {
            }
        }

      
    }
}
